import express from "express";
import connection from "./config/db.js";
import router from "./routes/index.js"
const app = express();

const Port = "8080";
const host = "localhost";

let con = await connection();

app.listen(Port, () => {
  console.log("server is running on " + host + " " + Port);
});

app.use(router)
