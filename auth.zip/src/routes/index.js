import express from "express";
import userRoutes from "./user.js"
const router = express();
router.use(express.json({extended:false}));
router.use("/user", userRoutes);


export default router