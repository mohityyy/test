import JWT from "jsonwebtoken"

const extractToken=(req)=>{
    
    if(req.headers.authorization) {
      console.log(req.headers.authorization);
        const header = req.headers.authorization.split(" ")
        const type = header[0];
        const token= header[1];
       
        if(type === "Bearer"){
            return token
        }
        return null;
    }else if(req.query && req.query.token){
        return req.query.token;
    }
return null;
}

const jwtVerify = (req , res , next)=>{
 
    if(req.headers.authorization){
        let token = extractToken(req)
        
        let verify = JWT.verify(token , "mohit")
        console.log(verify);
        if(verify){
            next()
        }else{
            return res.json({
                status:500,
                message:"Token not matched,"
            })
        }
    }else{
        return res.json({
            status:401,
            message:"Token mismacthed"
        })
    }
}

export default jwtVerify;
