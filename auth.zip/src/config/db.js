import mongoose from "mongoose";

async function connection() {
  mongoose.connect("mongodb://127.0.0.1:27017/nodelearn", {
    useNewUrlParser: true,
    autoIndex: true,
  });
  try {
    mongoose.connection.on("connected", () => {
      console.log("Mongo has connected successfully");
    });
  } catch (error) {
    console.log(error);
  }
}
export default connection;
