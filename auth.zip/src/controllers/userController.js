import User from "../models/User.js";
import JWT from "jsonwebtoken";

class userController {
  create = async (req, res) => {
    console.log("req", req.body);

    try {
      const { name, email, password } = req.body;
      let user = await new User({
        name: name,
        email: email,
        password: password,
      }).save();

      return res.json({
        status: true,
        message: "User Created successfully",
        data: user,
      });
    } catch (error) {
      console.log(error);
      return res.json({
        status: false,
        message: error,
      });
    }
  };

  login = async (req, res, next) => {
    try {
      const { email, password } = req.body;
      let user = await User.find({ email: email, password: password });
      if (user.length > 0) {
        let token = "";
        token = JWT.sign(
          {
            user,
          },
          "mohit"
        );
        return res.json({
          status: 200,
          message: "Login successfuly",
          data: user,
          token: token,
        });
      } else {
        return res.json({
          status: 401,
          message: "email / password incorrect",
        });
      }
    } catch (error) {
      console.log(error);
      return res.json({
        status: 500,
        message: error,
      });
    }
  };
}
export default new userController();
